#include "get_next_line.h"
#include <stdlib.h>
#include <unistd.h>

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 42
#endif

static char *append_buffer(char *storage, char *buffer)
{
    size_t i = 0, j = 0;
    while (storage && storage[i]) i++;
    while (buffer[j]) j++;
    char *new_storage = malloc(i + j + 1);
    if (!new_storage)
        return NULL;
    for (i = 0; storage && storage[i]; i++)
        new_storage[i] = storage[i];
    for (j = 0; buffer[j]; j++)
        new_storage[i + j] = buffer[j];
    new_storage[i + j] = '\0';
    free(storage);
    return new_storage;
}

static char *extract_line(char *storage)
{
    if (!storage)
        return NULL;
    size_t i = 0;
    while (storage[i] && storage[i] != '\n')
        i++;
    char *line = malloc(i + (storage[i] == '\n') + 1);
    if (!line)
        return NULL;
    for (size_t j = 0; j < i; j++)
        line[j] = storage[j];
    if (storage[i] == '\n')
        line[i++] = '\n';
    line[i] = '\0';
    return line;
}

static char *trim_storage(char *storage)
{
    size_t i = 0;
    while (storage[i] && storage[i] != '\n')
        i++;
    if (!storage[i]) {
        free(storage);
        return NULL;
    }
    char *new_storage = malloc(strlen(storage) - i);
    if (!new_storage)
        return NULL;
    size_t j = 0;
    for (i++; storage[i]; i++)
        new_storage[j++] = storage[i];
    new_storage[j] = '\0';
    free(storage);
    return new_storage;
}

char *get_next_line(int fd)
{
    static char *storage;
    char buffer[BUFFER_SIZE + 1];
    ssize_t bytes_read;

    if (fd < 0 || BUFFER_SIZE <= 0)
        return NULL;
    while ((bytes_read = read(fd, buffer, BUFFER_SIZE)) > 0) {
        buffer[bytes_read] = '\0';
        storage = append_buffer(storage, buffer);
        if (!storage)
            return NULL;
        if (strchr(storage, '\n'))
            break;
    }
    if (bytes_read < 0 || (!storage && bytes_read == 0))
        return NULL;
    char *line = extract_line(storage);
    storage = trim_storage(storage);
    return line;
}
